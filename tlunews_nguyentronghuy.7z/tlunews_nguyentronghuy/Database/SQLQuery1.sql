﻿USE [CSDL tintuc]
GO
-- Creating the 'users' table
CREATE TABLE users (
    id INT PRIMARY KEY IDENTITY(1,1),
    username VARCHAR(255) NOT NULL,
    password VARCHAR(255) NOT NULL,
    role INT CHECK (role IN (0, 1)) -- 0: user, 1: admin
);

-- Creating the 'categories' table
CREATE TABLE categories (
    id INT PRIMARY KEY IDENTITY(1,1),
    name VARCHAR(255) NOT NULL
);

-- Creating the 'news' table
CREATE TABLE news (
    id INT PRIMARY KEY IDENTITY(1,1),
    title NVARCHAR(255) NOT NULL,
    content TEXT NOT NULL,
    image VARCHAR(255),
    created_at DATETIME DEFAULT GETDATE(),
    category_id INT,
    FOREIGN KEY (category_id) REFERENCES categories(id)
);



-- Inserting data into the 'users' table
INSERT INTO users (username, password, role)
VALUES
('admin_user', 'admin_password', 1),
('regular_user', 'user_password', 0);

-- Inserting data into the 'categories' table
INSERT INTO categories (name)
VALUES
('Technology'),
('Health'),
('Sports'),
('Entertainment');

-- Inserting data into the 'news' table
INSERT INTO news (title, content, image, category_id, created_at)
VALUES
('Tech News 1', 'Content of tech news 1.', 'tech1.jpg', 1, GETDATE()),
('Health Tips 1', 'Content of health tips 1.', 'health1.jpg', 2, GETDATE()),
('Sports Update 1', 'Content of sports update 1.', 'sports1.jpg', 3, GETDATE()),
('Entertainment Buzz 1', 'Content of entertainment buzz 1.', 'entertainment1.jpg', 4, GETDATE());



-- In ra dữ liệu của bảng 'users'
SELECT * FROM users;

-- In ra dữ liệu của bảng 'categories'
SELECT * FROM categories;

-- In ra dữ liệu của bảng 'news'
SELECT * FROM news;
